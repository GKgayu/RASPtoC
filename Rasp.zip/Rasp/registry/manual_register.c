#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mysql.h>
#include <time.h>
//preshared key
struct Register
{
    char ename[100];
    char Pre_shared_key[50];   
}reg;
//To use for RSA algorithm
int prime_numbers[]={1009, 1013, 1019, 1021, 1031, 1033, 1039, 1049, 1051, 1061, 1063, 1069, 1087, 1091, 1093, 1097, 1103, 1109, 1117, 1123, 1129, 1151, 1153, 1163, 1171, 1181, 1187, 1193, 1201, 1213, 1217, 1223, 1229, 1231, 1237, 1249, 1259, 1277, 1279, 1283, 1289, 1291, 1297, 1301, 1303, 1307, 1319, 1321, 1327, 1361, 1367, 1373, 1381, 1399, 1409, 1423, 1427, 1429, 1433, 1439, 1447, 1451, 1453, 1459, 1471, 1481, 1483, 1487, 1489, 1493, 1499, 1511, 1523, 1531, 1543, 1549, 1553, 1559, 1567, 1571, 1579, 1583, 1597, 1601, 1607, 1609, 1613, 1619, 1621, 1627, 1637, 1657, 1663, 1667, 1669, 1693, 1697, 1699, 1709, 1721, 1723, 1733, 1741, 1747, 1753, 1759, 1777, 1783, 1787, 1789, 1801, 1811, 1823, 1831, 1847, 1861, 1867, 1871, 1873, 1877, 1879, 1889, 1901, 1907, 1913, 1931, 1933, 1949, 1951, 1973, 1979, 1987, 1993, 1997, 1999, 2003};

int x, y, n, t, i,pbkey,prkey,flag,num[2];
long int e[55050], d[55050], temp[55050], j, m[55050], en[55150];
char msg[100];
MYSQL *conn;
MYSQL_RES *res;
MYSQL_ROW row;
char *server = "localhost";
char *user = "root";
char *password = "rootroot"; /* set me first */
char *database = "rasp";

//function declaration
int prime(long int);
void encryption_key();
long int cd(long int);
void encrypt();
void decrypt();
void sql_conn();
void sql_exec_query();

int main()
{
  printf("Enter the Entity name:");//server SA or CLoud CB entity name
  scanf("%s",&reg.ename);
  printf("\nEnter the Pre-shared key:");
  scanf("%s",&reg.Pre_shared_key);
  srand(time(0)); 
  printRandoms(0,(sizeof(prime_numbers)/sizeof(prime_numbers[0]))-1,2);//Will take two prime numbers position
  rsa_encryption();

return 0;
}

//
void printRandoms(int lower, int upper,int count) //num 0, num 1
{ 
    int i;
    for (i = 0; i < count; i++) { 
        num[i]= (rand()%(upper-lower+1))+lower;
         
    } 
} 
//RSA algorithm
void rsa_encryption()
{
  x=prime_numbers[num[0]];
  flag = prime(x);
  
  
  y=prime_numbers[num[1]];
  
  flag = prime(y);
  if(flag == 0 || x == y)
  {
    printf("\nINVALID INPUT\n");
    exit(0);
  }
  n = x * y;
  t = (x-1) * (y-1);
  encryption_key();
  //printf("\nPOSSIBLE VALUES OF e AND d ARE\n");
  srand(time(0));
  /*for(i = 0; i < j-1; i++)
    printf("\n%ld\t%ld", e[i], d[i]);*/

  int kr = (rand()%((j-2)-0+1))+0;
    
  pbkey=e[kr];
  prkey=d[kr];
  //printf("\n%d\n%d\n",pbkey,prkey);
  sql_conn();
  sql_exec_query();

}

int prime(long int pr)
{
  int i;
  j = sqrt(pr);
  for(i = 2; i <= j; i++)
  {
   if(pr % i == 0)
     return 0;
  }
  return 1;
 }

//function to generate encryption key
void encryption_key()
{
  int k;
  k = 0;
  for(i = 2; i < t; i++)
  {
    if(t % i == 0)
     continue;
    flag = prime(i);
    if(flag == 1 && i != x && i != y)
    {
     e[k] = i;
     flag = cd(e[k]);
    if(flag > 0)
    {
     d[k] = flag;
     k++;
    }
   if(k == 99)
    break;
   }
 }
}
long int cd(long int a)
{
  long int k = 1;
  while(1)
  {
    k = k + t;
    if(k % a == 0)
     return(k / a);
  }
}

//function to encrypt the message
void encrypt()
{
  long int pt, ct, key = pbkey, k, len;
  i = 0;
  len = strlen(msg);
  while(i != len)
  {
    pt = m[i];
    pt = pt - 96;
    k = 1;
    for(j = 0; j < key; j++)
    {
     k = k * pt;
     k = k % n;
    }
   temp[i] = k;
   ct = k + 96;
   en[i] = ct;
   i++;
  }
  en[i] = -1;
  printf("\n\nTHE ENCRYPTED MESSAGE IS\n");
  for(i = 0; en[i] != -1; i++)
    printf("%c", en[i]);
}

//function to decrypt the message
void decrypt()
{
  long int pt, ct, key = prkey, k;
  i = 0;
  while(en[i] != -1)
  {
    ct = temp[i];
    k = 1;
    for(j = 0; j < key; j++)
    {
      k = k * ct;
      k = k % n;
    }
   pt = k + 96;
   m[i] = pt;
   i++;
  }
  m[i] = -1;
  printf("\n\nTHE DECRYPTED MESSAGE IS\n");
  for(i = 0; m[i] != -1; i++)
   printf("%c", m[i]);
  printf("\n");
}

void sql_conn()
{
  conn = mysql_init(NULL);
  
  /* Connect to database */
  if (!mysql_real_connect(conn, server, user, password, 
                                      database, 0, NULL, 0)) {
    fprintf(stderr, "%s\n", mysql_error(conn));
    exit(1);
  }
  
}

void sql_exec_query()
{
  char q[500];
  sprintf(q,"insert into regclients(name,psk,basex,basey,prkey,pbkey) values(\'%s\',\'%s\',%d,%d,%d,%d)",reg.ename,reg.Pre_shared_key,x,y,prkey,pbkey);
  if (mysql_query(conn,q)) {
    fprintf(stderr, "%s\n", mysql_error(conn));
    exit(1);  
  }
   
  res = mysql_use_result(conn);
  
  /* output table name */
  printf("Registered Successfully\n");
   
  
   
  /* close connection */
  mysql_free_result(res);
  mysql_close(conn);
}
   /*struct Register reg;
   FILE *fptr;
   strncpy(reg.Pre_shared_key_CB,"crkey",sizeof("crkey"));
   strncpy(reg.Pre_shared_key_SA,"srkey",sizeof("srkey"));

   if ((fptr = fopen("registered.bin","wb")) == NULL){
       printf("Error! opening file");

       // Program exits if the file pointer returns NULL.
       exit(1);
   }

   
  
      fwrite(&reg, sizeof(struct Register), 1, fptr); 
  
   fclose(fptr); 
  
  
*/
