#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<netdb.h>
#include<mysql.h>
#include<math.h>
#include<time.h>

MYSQL *conn;
MYSQL_RES *result;
MYSQL_ROW row;
char *server = "localhost";
char *user = "root";
char *password = "rootroot"; /* set me first */
char *database = "rasp";

unsigned int Max_resources_CPU;
unsigned int Max_resources_Memory;
unsigned int Max_resources_NETWORK;
unsigned int Max_resources_STORAGE;

unsigned int Max_allocated_CPU;
unsigned int Max_allocated_Memory;
unsigned int Max_allocated_NETWORK;
unsigned int Max_allocated_STORAGE;

unsigned int Max_free_CPU;
unsigned int Max_free_Memory;
unsigned int Max_free_NETWORK;
unsigned int Max_free_STORAGE;

unsigned int Req_resources_CPU;
unsigned int Req_resources_Memory;
unsigned int Req_resources_NETWORK;
unsigned int Req_resources_STORAGE;


unsigned int Req_resources_rCPU;
unsigned int Req_resources_rMemory;
unsigned int Req_resources_rNETWORK;
unsigned int Req_resources_rSTORAGE;
char requester_name[150];
char to_check_name[150];
int cpuflag=0;
int memflag=0;
int netflag=0;
int strgflag=0;
int req_cpu_choice;
int req_mem_choice;
int req_net_choice;
int req_strg_choice;
int basex,basey,key;
long int skr,sbk;
int is_valid=0;
char st[20];
int prime_numbers[]={1009, 1013, 1019, 1021, 1031, 1033, 1039, 1049, 1051, 1061, 1063, 1069, 1087, 1091, 1093, 1097, 1103, 1109, 1117, 1123, 1129, 1151, 1153, 1163, 1171, 1181, 1187, 1193, 1201, 1213, 1217, 1223, 1229, 1231, 1237, 1249, 1259, 1277, 1279, 1283, 1289, 1291, 1297, 1301, 1303, 1307, 1319, 1321, 1327, 1361, 1367, 1373, 1381, 1399, 1409, 1423, 1427, 1429, 1433, 1439, 1447, 1451, 1453, 1459, 1471, 1481, 1483, 1487, 1489, 1493, 1499, 1511, 1523, 1531, 1543, 1549, 1553, 1559, 1567, 1571, 1579, 1583, 1597, 1601, 1607, 1609, 1613, 1619, 1621, 1627, 1637, 1657, 1663, 1667, 1669, 1693, 1697, 1699, 1709, 1721, 1723, 1733, 1741, 1747, 1753, 1759, 1777, 1783, 1787, 1789, 1801, 1811, 1823, 1831, 1847, 1861, 1867, 1871, 1873, 1877, 1879, 1889, 1901, 1907, 1913, 1931, 1933, 1949, 1951, 1973, 1979, 1987, 1993, 1997, 1999, 2003};
int x, y, n, t, i,pbkey,prkey,flag,num[2],rx,ry;
long int e[55050], d[55050], temp[55050], j, m[55050], en[55150];
char msg[100];

void resources_valid();
void adv_resources_verify();
int prime(long int);
void encryption_key();
long int cd(long int);
char* encrypt(char*,char*);
char* decrypt(char*);
char enm[20];
char msn[20];
char* do_encrypt(char*,char*);

void printRandoms(int,int,int);
void server_connect();
void sql_conn();
char buffer[255];	
int sockfd,portno,n;
void error(const char *msg)
{
perror(msg);
exit(1);
}
int main(int argc,char *argv[]){


struct sockaddr_in serv_addr;
struct hostent *server;

char hostname[150];

//printf("Enter the hostname: ");
//scanf("%s",hostname);
strcpy(hostname,"localhost");
printf("Enter the port number: ");
scanf("%d",&portno);


sockfd=socket(AF_INET,SOCK_STREAM,0);
if(sockfd<0)
{
error("Error Opening Socket");
}

server=gethostbyname(hostname);
if(server==NULL)
{
fprintf(stderr,"Error no such host\n");
exit(0);	
}
bzero((char*)&serv_addr,sizeof(serv_addr));
serv_addr.sin_family=AF_INET;
bcopy((char*)server->h_addr,(char*)&serv_addr.sin_addr.s_addr,server->h_length);
serv_addr.sin_port=htons(portno);
if(connect(sockfd,(struct sockaddr*)&serv_addr,sizeof(serv_addr))<0)
error("Connection Failed");

//reading the entity name
bzero(buffer,255);
n=read(sockfd,buffer,255);
if(n<0)
error("Error on reading");
printf("\nConnected:%s",buffer);

if(strncmp(buffer,"cloud",5)==0)
{
	//asking to enter cloudname
bzero(buffer,255);
sprintf(buffer,"Enter the Cloud name: ");
n=write(sockfd,buffer,strlen(buffer));
if(n<0)
error("Error on Writing");

//reading the cloudname
bzero(buffer,255);
n=read(sockfd,buffer,255);
if(n<0)
error("Error on reading");
strcpy(requester_name,buffer);
printf("\nServer Name: %s",requester_name);

//asking to enter Servername
bzero(buffer,255);
sprintf(buffer,"Enter the Server name: ");
n=write(sockfd,buffer,strlen(buffer));
if(n<0)
error("Error on Writing");

//reading the server name
bzero(buffer,255);
n=read(sockfd,buffer,255);
if(n<0)
error("Error on reading");
strcpy(to_check_name,buffer);
printf("\nCloud name :%s",to_check_name);


//asking to enter ncpu
bzero(buffer,255);
sprintf(buffer,"Fetching.. server's requested number of CPU");
n=write(sockfd,buffer,strlen(buffer));
if(n<0)
error("Error on Writing");

//reading the ncpu
bzero(buffer,255);
n=read(sockfd,buffer,255);
if(n<0)
error("Error on reading");
Req_resources_CPU=atoi(buffer);
printf("\nRequested number of CPU: %d",Req_resources_CPU);

//asking to enter nmem
bzero(buffer,255);
sprintf(buffer,"Fetching.. server's requested number of Memory");
n=write(sockfd,buffer,strlen(buffer));
if(n<0)
error("Error on Writing");

//reading the nmem
bzero(buffer,255);
n=read(sockfd,buffer,255);
if(n<0)
error("Error on reading");
Req_resources_Memory=atoi(buffer);
printf("\nRequested number of memory: %d",Req_resources_Memory);

//asking to enter nnet
bzero(buffer,255);
sprintf(buffer,"Fetching.. server's requested number of Network");
n=write(sockfd,buffer,strlen(buffer));
if(n<0)
error("Error on Writing");

//reading the nnet
bzero(buffer,255);
n=read(sockfd,buffer,255);
if(n<0)
error("Error on reading");
Req_resources_NETWORK=atoi(buffer);
printf("\nRequested number of network: %d",Req_resources_NETWORK);

//asking to enter nstrage
bzero(buffer,255);
sprintf(buffer,"Fetching.. server's requested number of Storage");
n=write(sockfd,buffer,strlen(buffer));
if(n<0)
error("Error on Writing");

//reading the nstorage
bzero(buffer,255);
n=read(sockfd,buffer,255);
if(n<0)
error("Error on reading");
Req_resources_STORAGE=atoi(buffer);
printf("\nRequested number of storage: %d\n",Req_resources_STORAGE);
server_resources_verify();


if(cpuflag==1 && memflag==1 && netflag==1 && strgflag==1)
server_resources_valid();

else
{
bzero(buffer,255);
sprintf(buffer,"oops...Server requested resources are not valid...");
n=write(sockfd,buffer,strlen(buffer));
if(n<0)
error("Error on Writing");

}
}
if(strncmp(buffer,"server",6)==0)
{
//asking to enter servername
bzero(buffer,255);
sprintf(buffer,"Enter the Server name: ");
n=write(sockfd,buffer,strlen(buffer));
if(n<0)
error("Error on Writing");

//reading the servvername
bzero(buffer,255);
n=read(sockfd,buffer,255);
if(n<0)
error("Error on reading");
strcpy(requester_name,buffer);
printf("\nServer Name: %s",requester_name);

//asking to enter cloudname
bzero(buffer,255);
sprintf(buffer,"Enter the Cloud name: ");
n=write(sockfd,buffer,strlen(buffer));
if(n<0)
error("Error on Writing");

//reading the cloud name
bzero(buffer,255);
n=read(sockfd,buffer,255);
if(n<0)
error("Error on reading");
strcpy(to_check_name,buffer);
printf("\nCloud name :%s",to_check_name);

//asking to enter ncpu
bzero(buffer,255);
sprintf(buffer,"Enter the number of resources that you want:\n CPU: ");
n=write(sockfd,buffer,strlen(buffer));
if(n<0)
error("Error on Writing");

//reading the ncpu
bzero(buffer,255);
n=read(sockfd,buffer,255);
if(n<0)
error("Error on reading");
Req_resources_CPU=atoi(buffer);
printf("\nRequested number of CPU: %d",Req_resources_CPU);

//asking to enter nmem
bzero(buffer,255);
sprintf(buffer,"Memory: ");
n=write(sockfd,buffer,strlen(buffer));
if(n<0)
error("Error on Writing");

//reading the nmem
bzero(buffer,255);
n=read(sockfd,buffer,255);
if(n<0)
error("Error on reading");
Req_resources_Memory=atoi(buffer);
printf("\nRequested number of memory: %d",Req_resources_Memory);

//asking to enter nnet
bzero(buffer,255);
sprintf(buffer,"Network: ");
n=write(sockfd,buffer,strlen(buffer));
if(n<0)
error("Error on Writing");

//reading the nnet
bzero(buffer,255);
n=read(sockfd,buffer,255);
if(n<0)
error("Error on reading");
Req_resources_NETWORK=atoi(buffer);
printf("\nRequested number of network: %d",Req_resources_NETWORK);

//asking to enter nstrage
bzero(buffer,255);
sprintf(buffer,"STORAGE: ");
n=write(sockfd,buffer,strlen(buffer));
if(n<0)
error("Error on Writing");

//reading the nstorage
bzero(buffer,255);
n=read(sockfd,buffer,255);
if(n<0)
error("Error on reading");
Req_resources_STORAGE=atoi(buffer);
printf("\nRequested number of storage: %d\n",Req_resources_STORAGE);

adv_resources_verify();

if(Req_resources_CPU>0||Req_resources_Memory>0||Req_resources_NETWORK>0||Req_resources_STORAGE>0)
resources_valid();
else
{
bzero(buffer,255);
sprintf(buffer,"Sorry for inconvenience... meet again...");
n=write(sockfd,buffer,strlen(buffer));
if(n<0)
error("Error on Writing");

}

}




close(sockfd);
return(0);
}

void server_resources_valid()
{
	sql_conn();

	char q[500];
	srand(time(0)); 
	printRandoms(0,(sizeof(prime_numbers)/sizeof(prime_numbers[0]))-1,2);
	x=prime_numbers[num[0]];
	flag = prime(x);
	rx=x;
	y=prime_numbers[num[1]];
	ry=y;
	flag = prime(y);
	if(flag == 0 || x == y)
	{
		printf("\nINVALID INPUT\n");
		exit(0);
	}
	n = x * y;
	t = (x-1) * (y-1);
	encryption_key();
	srand(time(0));
	int kr = (rand()%((j-2)-0+1))+0;

	sbk=e[kr];
	skr=d[kr];


	sprintf(q,"insert into regvalidsign(requester,check_for,basex,basey,pukey,rcpu,rmem,rnet,rstrg,regx,regy,sbk,skr) values(\'%s\',\'%s\',%d,%d,%d,%d,%d,%d,%d,%d,%d,%ld,%ld)",requester_name,to_check_name,basex,basey,key,Req_resources_CPU,Req_resources_Memory,Req_resources_NETWORK,Req_resources_STORAGE,x,y,sbk,skr);
	if (mysql_query(conn,q)) 
	{
		fprintf(stderr, "%s\n", mysql_error(conn));
		exit(1);  
	}

	result = mysql_use_result(conn);

	/* close connection */
	mysql_free_result(result);
	mysql_close(conn);
	bzero(buffer,255);
	sprintf(buffer,"valid");
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");

	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");


	bzero(buffer,255);
	sprintf(buffer,"skr: ");
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");

	bzero(buffer,255);
	sprintf(buffer,"%ld",skr);
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");

	bzero(buffer,255);
	sprintf(buffer,"Cloud Name: ");
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");


	strcpy(enm,do_encrypt(to_check_name,"../cloudCB/encreg/servername.txt"));
	bzero(buffer,255);
	sprintf(buffer,"%s",enm);
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");

	bzero(buffer,255);
	sprintf(buffer,"pksa: ");
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
	error("Error on reading");


	bzero(buffer,255);

	sprintf(st,"%d",key);
	sprintf(buffer,"%s",do_encrypt(st,"../cloudCB/encreg/ckey.txt"));
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");

	bzero(buffer,255);
	sprintf(buffer,"%s","Req_resources_CPU:");
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");
	

	bzero(buffer,255);
	sprintf(st,"%d",Req_resources_CPU);
	sprintf(buffer,"%s",do_encrypt(st,"../cloudCB/encreg/reqcpu.txt"));
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");


	bzero(buffer,255);
	sprintf(buffer,"%s","Req_resources_Memory:");
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");

	bzero(buffer,255);
	sprintf(st,"%d",Req_resources_Memory);
	sprintf(buffer,"%s",do_encrypt(st,"../cloudCB/encreg/reqmem.txt"));
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");

	bzero(buffer,255);
	sprintf(buffer,"%s","Req_resources_NETWORK:");
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");


	bzero(buffer,255);
	sprintf(st,"%d",Req_resources_NETWORK);
	sprintf(buffer,"%s",do_encrypt(st,"../cloudCB/encreg/reqnet.txt"));
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");

	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");


	bzero(buffer,255);
	sprintf(buffer,"%s","Req_resources_STORAGE:");
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");


	bzero(buffer,255);
	sprintf(st,"%d",Req_resources_STORAGE);
	sprintf(buffer,"%s",do_encrypt(st,"../cloudCB/encreg/reqstrg.txt"));
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");

}
void sql_conn()
{
conn = mysql_init(NULL);

/* Connect to database */
if (!mysql_real_connect(conn, server, user, password,database, 0, NULL, 0)) {
fprintf(stderr, "%s\n", mysql_error(conn));
exit(1);
}

}
void server_resources_verify()
{
	sql_conn();
	char q[500];
	sprintf(q,"SELECT * FROM regvalidsign AS rv INNER JOIN regclients AS r ON rv.requester = r.name AND rv.requester=\'%s\'",to_check_name);
	if (mysql_query(conn,q)) 
	{
		fprintf(stderr, "%s\n", mysql_error(conn));
		exit(1);  
	}

	result = mysql_use_result(conn);


	if((row = mysql_fetch_row(result)) != NULL)
	{
		Req_resources_rCPU=atoi(row[6]);
		Req_resources_rMemory=atoi(row[7]);
		Req_resources_rNETWORK=atoi(row[8]);
		Req_resources_rSTORAGE=atoi(row[9]);
	
		basex=atoi(row[17]);

		basey=atoi(row[18]);
		key=atoi(row[20]);
		is_valid=1;
	}
	


	if(Req_resources_CPU==Req_resources_CPU)
	{
		//condition true write ok
		cpuflag=1;
		bzero(buffer,255);
		sprintf(buffer,"Valid");
		n=write(sockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");

	}
	else
	{
		cpuflag=0;
		bzero(buffer,255);
		sprintf(buffer,"Requested CPU Not Valid");
		n=write(sockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");

	}
		
	

	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");

	if(Req_resources_Memory==Req_resources_rMemory)
	{
		//condition true write ok

		memflag=1;
		bzero(buffer,255);
		sprintf(buffer,"Valid");
		n=write(sockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");

	}
	else
	{
		memflag=0;
		bzero(buffer,255);
		sprintf(buffer,"Requested Memory Not Valid");
		n=write(sockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");

	}
	
	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");

	if(Req_resources_NETWORK==Req_resources_rNETWORK)
	{
		//condition true write ok
		netflag=1;
		bzero(buffer,255);
		sprintf(buffer,"Valid");
		n=write(sockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");

	}
	else
	{
		netflag=0;
		bzero(buffer,255);
		sprintf(buffer,"Requested Network Not Valid");
		n=write(sockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");

	}

	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");

	if(Req_resources_STORAGE==Req_resources_rSTORAGE)
	{
		//condition true write ok
		strgflag=1;
		bzero(buffer,255);
		sprintf(buffer,"Valid");
		n=write(sockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");

	}
	else
	{
		strgflag=0;
		bzero(buffer,255);
		sprintf(buffer,"Requested Storage Not Valid");
		n=write(sockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");

	}

	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");



	/* close connection */
	mysql_free_result(result);
	mysql_close(conn);
}
void adv_resources_verify()
{
	sql_conn();
	char q[500];
	sprintf(q,"SELECT * FROM advertisement AS ad INNER JOIN regclients AS r ON ad.cloudname = r.name AND ad.cloudname=\'%s\'",to_check_name);
	if (mysql_query(conn,q)) 
	{
		fprintf(stderr, "%s\n", mysql_error(conn));
		exit(1);  
	}

	result = mysql_use_result(conn);


	if((row = mysql_fetch_row(result)) != NULL)
	{
		Max_resources_CPU=atoi(row[2]);
		Max_resources_Memory=atoi(row[3]);
		Max_resources_NETWORK=atoi(row[4]);
		Max_resources_STORAGE=atoi(row[5]);
		Max_allocated_CPU=atoi(row[6]);
		Max_allocated_Memory=atoi(row[7]);
		Max_allocated_NETWORK=atoi(row[8]);
		Max_allocated_STORAGE=atoi(row[9]);
		Max_free_CPU=Max_resources_CPU-Max_allocated_CPU;
		Max_free_Memory=Max_resources_Memory-Max_allocated_Memory;
		Max_free_NETWORK=Max_resources_NETWORK-Max_allocated_NETWORK;
		Max_free_STORAGE=Max_resources_STORAGE-Max_allocated_STORAGE;
		basex=atoi(row[13]);
		basey=atoi(row[14]);
		key=atoi(row[16]);
		is_valid=1;
	}
	//printf("%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d",Max_resources_CPU,Max_resources_STORAGE,Max_resources_NETWORK,Max_allocated_Memory,Max_allocated_CPU,Max_allocated_Memory,Max_allocated_STORAGE,Max_allocated_NETWORK,basex,basey,key);

	while(cpuflag==0)
	{


		if(Max_free_CPU>Req_resources_CPU)
		{
			//condition true write ok
			cpuflag=1;
			bzero(buffer,255);
			sprintf(buffer,"OK");
			n=write(sockfd,buffer,strlen(buffer));
			if(n<0)
				error("Error on Writing");

		}

		if(cpuflag==0)
		{
			//condition false write not ok
			bzero(buffer,255);
			sprintf(buffer,"Your current requested number of CPU are more than maximum number of resources.to change your input press 0 or to skip CPU resources press any other numbers  ");
			n=write(sockfd,buffer,strlen(buffer));
			if(n<0)
				error("Error on Writing");

			//read the respnse from server
			bzero(buffer,255);
			n=read(sockfd,buffer,255);
			if(n<0)
				error("Error on reading");
			req_cpu_choice=atoi(buffer);


			if(req_cpu_choice==0)
			{
				//reasking the ncpu
				bzero(buffer,255);
				sprintf(buffer,"CPU: ");
				n=write(sockfd,buffer,strlen(buffer));
				if(n<0)
					error("Error on Writing");

				//read the ncpu
				bzero(buffer,255);
				n=read(sockfd,buffer,255);
				if(n<0)
					error("Error on reading");
				Req_resources_CPU=atoi(buffer);
				printf("\nReq_resources_CPU change to %d",Req_resources_CPU);
			}
			else
			{
				Req_resources_CPU=0;
				printf("\nReq_resources_CPU are cancelled");
			}

		}

	}

	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");

	while(memflag==0)
	{
		if(Max_free_Memory>Req_resources_Memory)
		{
		//condition true write ok
		memflag=1;
		bzero(buffer,255);
		sprintf(buffer,"OK");
		n=write(sockfd,buffer,2);
		if(n<0)
		error("Error on Writing");

		}

		if(memflag==0)
		{
		//condition false write not ok
		bzero(buffer,255);
		sprintf(buffer,"Your current requested number of Memory are more than maximum number of resources.to change your input press 0 or to skip Memory resources press any other numbers  ");
		n=write(sockfd,buffer,strlen(buffer));
		if(n<0)
		error("Error on Writing");

		//read the respnse from server
		bzero(buffer,255);
		n=read(sockfd,buffer,255);
		if(n<0)
		error("Error on reading");
		req_mem_choice=atoi(buffer);

		if(req_mem_choice==0)
		{
		//reasking the nmemory

		bzero(buffer,255);
		sprintf(buffer,"Memory: ");
		n=write(sockfd,buffer,strlen(buffer));
		if(n<0)
		error("Error on Writing");

		//read the nmemory
		bzero(buffer,255);
		n=read(sockfd,buffer,255);
		if(n<0)
		error("Error on reading");
		Req_resources_Memory=atoi(buffer);
		printf("\nReq_resources_Memory change to %d",Req_resources_Memory);
		}
		else
		{
		Req_resources_Memory=0;
		printf("\nReq_resources_Memory are cancelled");
		}

		}
	}
	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");

	do{
		if(Max_free_NETWORK>Req_resources_NETWORK)
		{		
			//condition true write ok
			netflag=1;
			bzero(buffer,255);
			sprintf(buffer,"OK");
			n=write(sockfd,buffer,strlen(buffer));
			if(n<0)
				error("Error on Writing");
		}

		if(netflag==0)
		{
			//condition false write not ok
			bzero(buffer,255);
			sprintf(buffer,"Your current requested number of Network are more than maximum number of resources.to change your input press 0 or to skip Network resources press any other numbers  ");
			n=write(sockfd,buffer,strlen(buffer));
			if(n<0)
			error("Error on Writing");

			//read the respnse from server
			bzero(buffer,255);
			n=read(sockfd,buffer,255);
			if(n<0)
			error("Error on reading");
			req_net_choice=atoi(buffer);

			if(req_net_choice==0)
			{
			//reasking the nnet

			bzero(buffer,255);
			sprintf(buffer,"Network: ");
			n=write(sockfd,buffer,strlen(buffer));
			if(n<0)
			error("Error on Writing");

			//read the nnet
			bzero(buffer,255);
			n=read(sockfd,buffer,255);
			if(n<0)
			error("Error on reading");
			Req_resources_NETWORK=atoi(buffer);
			printf("\nReq_resources_Network change to %d",Req_resources_NETWORK);
			}
			else
			{
			Req_resources_NETWORK=0;
			printf("\nReq_resources_Network are cancelled");
			}
		}
	}while(netflag==0);

	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
	error("Error on reading");
	do
	{
	if(Max_free_STORAGE>Req_resources_STORAGE)
	{
	//condition true write ok
	strgflag=1;
	bzero(buffer,255);
	sprintf(buffer,"OK");
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
	error("Error on Writing");
	}

	if(strgflag==0)
	{
	//condition false write not ok
	bzero(buffer,255);
	sprintf(buffer,"Your current requested number of Storage are more than maximum number of resources.to change your input press 0 or to skip Storage resources press any other numbers  ");
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
	error("Error on Writing");

	//read the respnse from server
	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
	error("Error on reading");
	req_strg_choice=atoi(buffer);

	if(req_strg_choice==0)
	{
	//reasking the nstrg
	bzero(buffer,255);
	sprintf(buffer,"STORAGE: ");
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
	error("Error on Writing");

	//read the nstrg
	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
	error("Error on reading");
	Req_resources_STORAGE=atoi(buffer);
	printf("\nReq_resources_STORAGE change to %d",Req_resources_STORAGE);
	}
	else
	{
	Req_resources_STORAGE=0;
	printf("\nReq_resources_STORAGE are cancelled");
	}

	}

	}while(strgflag==0);

	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
	error("Error on reading");




	/* close connection */
	mysql_free_result(result);
	mysql_close(conn);
}
void resources_valid()
{
	sql_conn();

	char q[500];
	srand(time(0)); 
	printRandoms(0,(sizeof(prime_numbers)/sizeof(prime_numbers[0]))-1,2);
	x=prime_numbers[num[0]];
	flag = prime(x);
	rx=x;
	y=prime_numbers[num[1]];
	ry=y;
	flag = prime(y);
	if(flag == 0 || x == y)
	{
		printf("\nINVALID INPUT\n");
		exit(0);
	}
	n = x * y;
	t = (x-1) * (y-1);
	encryption_key();
	srand(time(0));
	int kr = (rand()%((j-2)-0+1))+0;

	sbk=e[kr];
	skr=d[kr];


	sprintf(q,"insert into regvalidsign(requester,check_for,basex,basey,pukey,rcpu,rmem,rnet,rstrg,regx,regy,sbk,skr) values(\'%s\',\'%s\',%d,%d,%d,%d,%d,%d,%d,%d,%d,%ld,%ld)",requester_name,to_check_name,basex,basey,key,Req_resources_CPU,Req_resources_Memory,Req_resources_NETWORK,Req_resources_STORAGE,x,y,sbk,skr);
	if (mysql_query(conn,q)) 
	{
		fprintf(stderr, "%s\n", mysql_error(conn));
		exit(1);  
	}

	result = mysql_use_result(conn);

	/* close connection */
	mysql_free_result(result);
	mysql_close(conn);
	bzero(buffer,255);
	sprintf(buffer,"valid");
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");

	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");


	bzero(buffer,255);
	sprintf(buffer,"skr: ");
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");

	bzero(buffer,255);
	sprintf(buffer,"%ld",skr);
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");

	bzero(buffer,255);
	sprintf(buffer,"Cloud Name: ");
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");


	strcpy(enm,do_encrypt(to_check_name,"../serverSA/encreg/cloudname.txt"));
	bzero(buffer,255);
	sprintf(buffer,"%s",enm);
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");

	bzero(buffer,255);
	sprintf(buffer,"pkcb: ");
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
	error("Error on reading");


	bzero(buffer,255);

	sprintf(st,"%d",key);
	sprintf(buffer,"%s",do_encrypt(st,"../serverSA/encreg/ckey.txt"));
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");

	bzero(buffer,255);
	sprintf(buffer,"%s","Max_free_CPU:");
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");


	bzero(buffer,255);
	sprintf(st,"%d",Max_free_CPU);
	sprintf(buffer,"%s",do_encrypt(st,"../serverSA/encreg/reqcpu.txt"));
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");


	bzero(buffer,255);
	sprintf(buffer,"%s","Max_free_Memory:");
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");

	bzero(buffer,255);
	sprintf(st,"%d",Max_free_Memory);
	sprintf(buffer,"%s",do_encrypt(st,"../serverSA/encreg/reqmem.txt"));
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");

	bzero(buffer,255);
	sprintf(buffer,"%s","Max_free_NETWORK:");
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");


	bzero(buffer,255);
	sprintf(st,"%d",Max_free_NETWORK);
	sprintf(buffer,"%s",do_encrypt(st,"../serverSA/encreg/reqnet.txt"));
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");

	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");


	bzero(buffer,255);
	sprintf(buffer,"%s","Max_free_STORAGE:");
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");


	bzero(buffer,255);
	sprintf(st,"%d",Max_free_STORAGE);
	sprintf(buffer,"%s",do_encrypt(st,"../serverSA/encreg/reqstrg.txt"));
	n=write(sockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");

}
char* do_encrypt(char *msg, char *nm)
{
	x=rx;
	flag = prime(x);
	if(flag == 0)
	{
		printf("\nINVALID INPUT\n");
		exit(0);
	}

	y=ry;
	flag = prime(y);
	if(flag == 0 || x == y)
	{
		printf("\nINVALID INPUT\n");
		exit(0);
	}
	n = x * y;
	t = (x-1) * (y-1);
	encryption_key();

	strcpy(enm,encrypt(msg,nm));
	return(enm);
}
void printRandoms(int lower, int upper,int count) 
{ 
	int i;
	for (i = 0; i < count; i++) 
	{ 
	num[i]= (rand()%(upper-lower+1))+lower;
	} 
} 



int prime(long int pr)
{
	int i;
	j = sqrt(pr);
	for(i = 2; i <= j; i++)
	{
		if(pr % i == 0)
			return 0;
	}
	return 1;
}

//function to generate encryption key
void encryption_key()
{
	int k;
	k = 0;
	for(i = 2; i < t; i++)
	{
		if(t % i == 0)
			continue;
		flag = prime(i);
		if(flag == 1 && i != x && i != y)
		{
			e[k] = i;
			flag = cd(e[k]);
			if(flag > 0)
			{
				d[k] = flag;
				k++;
			}
			if(k == 99)
				break;
		}
	}
}

long int cd(long int a)
{
	long int k = 1;
	while(1)
	{
		k = k + t;
		if(k % a == 0)
		return(k / a);
	}
}

char* encrypt(char *msg,char *nm)
{

	for(i = 0; msg[i] != '\0'; i++)
		m[i] = msg[i];
	long int pt, ct, key = sbk, k, len;
	i = 0;
	len = strlen(msg);
	FILE *fptr;
	fptr=fopen(nm,"w");
	// if(fptr!=NULL)
	// {
	// 	printf("File created successfully");
	// }
	// else{
	// 	printf("Failed t0 create");
	// }

	while(i != len)
	{
		pt = m[i];
		pt = pt - 96;
		k = 1;
		for(j = 0; j < key; j++)
		{
			k = k * pt;
			k = (int)k % (int)n;
		}
		temp[i] = k;

		fprintf(fptr, "%ld\n", k);
		ct = k + 96;
		en[i] = ct;
		i++;

	}

	en[i] = -1;

	for(i = 0; en[i] != -1; i++)
	enm[i]=en[i];
	enm[i]='\0';
	fclose(fptr);
	return(enm);
}

//function to decrypt the message
char* decrypt(char* enm)
{
	//printf("skr:%ld",skr);
	long int pt, ct, key = skr, k;
	i = 0;
	while(en[i] != -1)
	{
		ct = temp[i];
		k = 1;
		for(j = 0; j < key; j++)
		{
			k = k * ct;
			k = k % n;
		}
		pt = k + 96;
		m[i] = pt;
		i++;
	}
	m[i] = -1;

	for(i = 0; m[i] != -1; i++)
		msn[i]=m[i];

	return(msn);
}
