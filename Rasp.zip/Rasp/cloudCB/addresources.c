//This file helps ot give resources such as CPU,memory etc.

#include <stdio.h>
#include <stdlib.h>
#include <mysql.h>

//Resources declaration
unsigned int Max_resources_CPU;
unsigned int Max_resources_Memory;
unsigned int Max_resources_NETWORK;
unsigned int Max_resources_STORAGE;

//Database connection - variables
char entity_name[150];
MYSQL *conn;
MYSQL_RES *result;
MYSQL_ROW row;
char *server = "localhost";
char *user = "root";
char *password = "rootroot"; /* set me first */
char *database = "rasp";

//Global Funtion declarations
void get_detail(); //CLoud CB has
void sql_conn();   //To insert into the CloudCb values;
void store_detail(); //Store details of CB

int main()
{
  get_detail();
  sql_conn();
  store_detail();
       
  mysql_close(conn);
  return 0;
}

void get_detail()
{
  printf("\nEnter the Cloud Name: ");
  scanf("%s",&entity_name);
  printf("Enter the number of resources:\nMax_resources_CPU: ");
  scanf("%d",&Max_resources_CPU);
  printf("\nMax_resources_Memory: ");
  scanf("%d",&Max_resources_Memory);
  printf("\nMax_resources_NETWORK: ");
  scanf("%d",&Max_resources_NETWORK);
  printf("\nMax_resources_STORAGE: ");
  scanf("%d",&Max_resources_STORAGE);

}

//Directly connecting to the database rasp;
void sql_conn()
{
  conn = mysql_init(NULL);
  
  /* Connect to database */
  if (!mysql_real_connect(conn, server, user, password,database, 0, NULL, 0)) {
    fprintf(stderr, "%s\n", mysql_error(conn));
    exit(1);
  }
  
}
//Before this, Create a table name:advertisement in rasp database.
void store_detail()
{
  char q[500];
  sprintf(q,"insert into advertisement(cloudname,ncpu,nmemory,nnetwork,nstorage) values(\'%s\',%d,%d,%d,%d)",entity_name,Max_resources_CPU,Max_resources_Memory,Max_resources_NETWORK,Max_resources_STORAGE);
  if (mysql_query(conn,q)) {
    fprintf(stderr, "%s\n", mysql_error(conn));
    exit(1);  
  }
   
  result = mysql_use_result(conn);
  
  /* output table name */
  printf("Registered Successfully\n");
   
  
   
  /* close connection */
  mysql_free_result(result);
  
}