#include <stdio.h>
#include <stdlib.h>
#include <mysql.h>
char entity_name[150];
MYSQL *conn;
MYSQL_RES *result;
MYSQL_ROW row;
char *server = "localhost";
char *user = "root";
char *password = "rootroot"; /* set me first */
char *database = "rasp";

void get_detail();
void sql_conn();
void show_detail();

int main()
{
 
  sql_conn();
  show_detail();
       
  mysql_close(conn);
  return 0;
}

void sql_conn()
{
  conn = mysql_init(NULL);
  
  /* Connect to database */
  if (!mysql_real_connect(conn, server, user, password,database, 0, NULL, 0)) {
    fprintf(stderr, "%s\n", mysql_error(conn));
    exit(1);
  }
  
}

void show_detail()
{
  char q[500];
  sprintf(q,"select * from advertisement");
  if (mysql_query(conn,q)) {
    fprintf(stderr, "%s\n", mysql_error(conn));
    exit(1);  
  }
   
  result = mysql_use_result(conn);
  
  /* output table name */
  printf("Resources Available are:\n");
   
  while ((row = mysql_fetch_row(result)) != NULL)
  {
    printf("Name :%s \n", row[1]);
    printf("CPU :%s \n", row[2]);
    printf("Memory :%s \n", row[3]);
    printf("Network :%s \n", row[4]);
    printf("Storage :%s \n", row[5]);
  }
   
  /* close connection */
  mysql_free_result(result);
  
}