#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<netdb.h>
#include<mysql.h>
#include<math.h>
#include<time.h>

MYSQL *conn;
MYSQL_RES *result;
MYSQL_ROW row;
char *server = "localhost";
char *user = "root";
char *password = "rootroot"; /* set me first */
char *database = "rasp";

struct Register
{
	char Pre_shared_key_C[50];
	char Pre_shared_key_SA[50];
}reg;
char st[20];
int rx,ry;
char Cloud_Name[150];
char *Server_Name="ServerSA";
long int skr;
long int sbk;
int prime_numbers[]={1009, 1013, 1019, 1021, 1031, 1033, 1039, 1049, 1051, 1061, 1063, 1069, 1087, 1091, 1093, 1097, 1103, 1109, 1117, 1123, 1129, 1151, 1153, 1163, 1171, 1181, 1187, 1193, 1201, 1213, 1217, 1223, 1229, 1231, 1237, 1249, 1259, 1277, 1279, 1283, 1289, 1291, 1297, 1301, 1303, 1307, 1319, 1321, 1327, 1361, 1367, 1373, 1381, 1399, 1409, 1423, 1427, 1429, 1433, 1439, 1447, 1451, 1453, 1459, 1471, 1481, 1483, 1487, 1489, 1493, 1499, 1511, 1523, 1531, 1543, 1549, 1553, 1559, 1567, 1571, 1579, 1583, 1597, 1601, 1607, 1609, 1613, 1619, 1621, 1627, 1637, 1657, 1663, 1667, 1669, 1693, 1697, 1699, 1709, 1721, 1723, 1733, 1741, 1747, 1753, 1759, 1777, 1783, 1787, 1789, 1801, 1811, 1823, 1831, 1847, 1861, 1867, 1871, 1873, 1877, 1879, 1889, 1901, 1907, 1913, 1931, 1933, 1949, 1951, 1973, 1979, 1987, 1993, 1997, 1999, 2003};
long int x,cx,cy,y, n, t, i,pbkey,prkey,flag,num[2],pkcb;
long int e[55050], d[55050], temp[55050], j, m[55050], en[55150];
char msg[100];
char* do_encrypt(char*,char*);
char* do_decrypt(char*,char*);
int prime(long int);
void encryption_key();
long int cd(long int);
char* encrypt(char*,char*);
char* decrypt(char*,char*);
char enm[20];
char msn[20];
int nonce;
unsigned int Req_resources_CPU;
unsigned int Req_resources_Memory;
unsigned int Req_resources_NETWORK;
unsigned int Req_resources_STORAGE;
void sql_conn();
void grab_basevalues();
void aencrypt_message();
void get_resourcevalues(char*);

void error(const char *msg)
{
	perror(msg);
	exit(0);
}
int sockfd,newsockfd,portno;
char buffer[255];
void connect_cloud()
	{
	//int sockfd,newsockfd,portno,n;
	char buffer[255];
	struct sockaddr_in serv_addr,cli_addr;
	socklen_t clilen;
	sockfd=socket(AF_INET,SOCK_STREAM,0);
	if(sockfd<0)
	{
		error("Error Opening Socket");
	}
	bzero((char*)&serv_addr,sizeof(serv_addr));
	printf("Enter the port number: ");
	scanf("%d",&portno);

	serv_addr.sin_family=AF_INET;
	serv_addr.sin_addr.s_addr=INADDR_ANY;
	serv_addr.sin_port=htons(portno);
	
	if(bind(sockfd,(struct sockaddr*)&serv_addr,sizeof(serv_addr))<0)
		error("Binding Failed");
	listen(sockfd,5);
	clilen=sizeof(cli_addr);
	newsockfd=accept(sockfd,(struct sockaddr*)&cli_addr,&clilen);
	
	if(newsockfd<0)
		error("Error on Accept");

	//intimating the connection
	bzero(buffer,255);
	strcpy(buffer,Server_Name);
	n=write(newsockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");

	//receiving the connection
	bzero(buffer,255);
	n=read(newsockfd,buffer,255); 
	if(n<0)
		error("Error on reading");
	printf("connected:%s\n",buffer);
	//strcpy(Cloud_Name,"CloudCB");
	get_resourcevalues(buffer);
	aencrypt_message();

}

int nonce_create()
{
	srand(time(0));
	int random = (((rand() & 255)<<8 | (rand() & 255))<<8 | (rand() & 255))<<7 | (rand() & 127);
	return(random);
}

void aencrypt_message ()
{
	//send nonce
	bzero(buffer,255);
	sprintf(buffer,"Nonce: ");
	n=write(newsockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(newsockfd,buffer,255);
	if(n<0)
		error("Error on reading");

	bzero(buffer,255);
	sprintf(st,"%d",nonce);
	sprintf(buffer,"%s",do_encrypt(st,"../cloudCB/encser/non.txt"));
	n=write(newsockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");

	bzero(buffer,255);
	n=read(newsockfd,buffer,255);
	if(n<0)
		error("Error on reading");

	bzero(buffer,255);
	sprintf(buffer,"Server Name: ");
	n=write(newsockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");

	bzero(buffer,255);
	n=read(newsockfd,buffer,255);
	if(n<0)
		error("Error on reading");

	strcpy(enm,do_encrypt(Server_Name,"../cloudCB/encser/servername.txt"));

	bzero(buffer,255);
	sprintf(buffer,"%s",enm);
	n=write(newsockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(newsockfd,buffer,255);
	if(n<0)
		error("Error on reading");

	bzero(buffer,255);
	sprintf(buffer,"%s","Req_resources_CPU:");
	n=write(newsockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(newsockfd,buffer,255);
	if(n<0)
		error("Error on reading");


	bzero(buffer,255);
	sprintf(st,"%d",Req_resources_CPU);
	sprintf(buffer,"%s",do_encrypt(st,"../cloudCB/encser/reqcpu.txt"));
	n=write(newsockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(newsockfd,buffer,255);
	if(n<0)
		error("Error on reading");


	bzero(buffer,255);
	sprintf(buffer,"%s","Req_resources_Memory:");
	n=write(newsockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(newsockfd,buffer,255);
	if(n<0)
		error("Error on reading");

	bzero(buffer,255);
	sprintf(st,"%d",Req_resources_Memory);
	sprintf(buffer,"%s",do_encrypt(st,"../cloudCB/encser/reqmem.txt"));
	n=write(newsockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(newsockfd,buffer,255);
	if(n<0)
		error("Error on reading");

	bzero(buffer,255);
	sprintf(buffer,"%s","Req_resources_NETWORK:");
	n=write(newsockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(newsockfd,buffer,255);
	if(n<0)
		error("Error on reading");



	bzero(buffer,255);
	sprintf(st,"%d",Req_resources_NETWORK);
	sprintf(buffer,"%s",do_encrypt(st,"../cloudCB/encser/reqnet.txt"));
	n=write(newsockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");

	bzero(buffer,255);
	n=read(newsockfd,buffer,255);
	if(n<0)
		error("Error on reading");


	bzero(buffer,255);
	sprintf(buffer,"%s","Req_resources_STORAGE:");
	n=write(newsockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	bzero(buffer,255);
	n=read(newsockfd,buffer,255);
	if(n<0)
		error("Error on reading");


	bzero(buffer,255);
	sprintf(st,"%d",Req_resources_STORAGE);
	sprintf(buffer,"%s",do_encrypt(st,"../cloudCB/encser/reqstrg.txt"));
	n=write(newsockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");

	close(sockfd);
	close(newsockfd);
}

void get_resourcevalues(char *s_name)
{
	
	sql_conn();
	char q[500];
	sprintf(q,"select * from regvalidsign where check_for=\'%s\'",s_name);
	
	if (mysql_query(conn,q)) 
	{
		fprintf(stderr, "%s\n", mysql_error(conn));
		exit(1);  
	}

	result = mysql_use_result(conn);

	while ((row = mysql_fetch_row(result)) != NULL)
	{
		rx=atoi(row[3]);
		ry=atoi(row[4]);
		pkcb=atoi(row[5]);
		Req_resources_CPU=atoi(row[6]);
		Req_resources_Memory=atoi(row[7]);
		Req_resources_NETWORK=atoi(row[8]);
		Req_resources_STORAGE=atoi(row[9]);
	}

	/* close connection */
	mysql_free_result(result);
	mysql_close(conn);

	nonce=nonce_create();
	sql_conn();
		sprintf(q,"insert into sacb(nonce,sendby,sendto,rcpu,rmem,rnet,rstrg) values(%d,\'%s\',\'%s\',%d,%d,%d,%d)",nonce,Server_Name,s_name,Req_resources_CPU,Req_resources_Memory,Req_resources_NETWORK,Req_resources_STORAGE);
	if (mysql_query(conn,q)) 
	{
		fprintf(stderr, "%s\n", mysql_error(conn));
		exit(1);  
	}

	result = mysql_use_result(conn);

	/* close connection */
	mysql_free_result(result);
	mysql_close(conn);

	
}

void registry_connect()
{

	int sockfd,newsockfd,portno,n;
	char buffer[255];
	struct sockaddr_in serv_addr,cli_addr;
	socklen_t clilen;
	sockfd=socket(AF_INET,SOCK_STREAM,0);
	if(sockfd<0)
	{
		error("Error Opening Socket");
	}
	bzero((char*)&serv_addr,sizeof(serv_addr));
	
	printf("Enter the port number: ");
	scanf("%d",&portno);

	serv_addr.sin_family=AF_INET;
	serv_addr.sin_addr.s_addr=INADDR_ANY;
	serv_addr.sin_port=htons(portno);
	
	if(bind(sockfd,(struct sockaddr*)&serv_addr,sizeof(serv_addr))<0)
		error("Binding Failed");
	listen(sockfd,5);
	clilen=sizeof(cli_addr);
	newsockfd=accept(sockfd,(struct sockaddr*)&cli_addr,&clilen);
	
	if(newsockfd<0)
		error("Error on Accept");

	//intimating that it was a server
	bzero(buffer,255);
	strcpy(buffer,"server");
	n=write(newsockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");

	// reading the question from registry
	bzero(buffer,255);
	n=read(newsockfd,buffer,255); 
	if(n<0)
		error("Error on reading");
	printf("%s",buffer);

	//entering the server name
	bzero(buffer,255);
	scanf("%s",buffer);
	n=write(newsockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");

	//reading the question from registry
	bzero(buffer,255);
	n=read(newsockfd,buffer,255); 
	if(n<0)
		error("Error on reading");
	printf("%s",buffer);

	//entering the cloud name
	bzero(buffer,255);
	scanf("%s",buffer);
	n=write(newsockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");

	//reading the question from registry
	bzero(buffer,255);
	n=read(newsockfd,buffer,255); //regidter asking ncpu
	if(n<0)
		error("Error on reading");
	printf("%s",buffer);

	//entering the number of cpus
	bzero(buffer,255);
	scanf("%s",buffer);
	n=write(newsockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");

	//reading the question from registry
	bzero(buffer,255);
	n=read(newsockfd,buffer,255); //regidter asking nmem
	if(n<0)
		error("Error on reading");
	printf("%s",buffer);

	//entering the number of memory
	bzero(buffer,255);
	scanf("%s",buffer);
	n=write(newsockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");

	//reading the question from registry
	bzero(buffer,255);
	n=read(newsockfd,buffer,255); //regidter asking nnet
	if(n<0)
		error("Error on reading");
	printf("%s",buffer);

	//entering the number of network
	bzero(buffer,255);
	scanf("%s",buffer);
	n=write(newsockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");

	//reading the question from registry
	bzero(buffer,255);
	n=read(newsockfd,buffer,255); //regidter asking nstr
	if(n<0)
		error("Error on reading");
	printf("%s",buffer);

	//entering the number of storage
	bzero(buffer,255);
	scanf("%s",buffer);
	n=write(newsockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");

	//read condition ok or not ok

	bzero(buffer,255);
	n=read(newsockfd,buffer,255); //read ok for cpu
	if(n<0)
		error("Error on reading");
	printf("%s\n",buffer);
	char temmsg[250];

	strcpy(temmsg,buffer);
	while(strncmp(temmsg,"OK",2)!=0)
	{
	//write the response to change the value
		bzero(buffer,255);
		scanf("%s",buffer);
		n=write(newsockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");
		if(atoi(buffer)==0)
		{
			//registry asked to enter the ncpu
			bzero(buffer,255);
			n=read(newsockfd,buffer,255); 
			if(n<0)
				error("Error on reading");
			printf("%s",buffer);

			//entering the ncpu
			bzero(buffer,255);
			scanf("%s",buffer);
			n=write(newsockfd,buffer,strlen(buffer));
			if(n<0)
				error("Error on Writing");

		}

	//read ok for cpu
		bzero(buffer,255);
		n=read(newsockfd,buffer,sizeof(buffer)); 
		if(strncmp(buffer,"OK",2)==0)
			break;

		if(n<0)
			error("Error on reading");
		printf("%s\n",buffer);
		strcpy(temmsg,buffer);
	}
	bzero(buffer,255);
	strcpy(buffer,"******");
	n=write(newsockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");


	//read condition ok or not ok
	bzero(buffer,255);
	n=read(newsockfd,buffer,255); //read ok for mem
	if(n<0)
		error("Error on reading");
	printf("\n%s",buffer);

	while(strncmp(buffer,"OK",2)!=0)
	{
		//write the response to change the value
		bzero(buffer,255);
		scanf("%s",buffer);
		n=write(newsockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");
		if(atoi(buffer)==0)
		{
			//registry asked to enter the nmem
			bzero(buffer,255);
			n=read(newsockfd,buffer,255); 
			if(n<0)
				error("Error on reading");
			printf("%s",buffer);

			//entering the nmem
				bzero(buffer,255);
			scanf("%s",buffer);
			n=write(newsockfd,buffer,strlen(buffer));
			if(n<0)
				error("Error on Writing");

		}

		//read ok for Memory
		bzero(buffer,255);
		n=read(newsockfd,buffer,255); 
		if(n<0)
		error("Error on reading");
		printf("%s\n",buffer);

	}

	bzero(buffer,255);
	strcpy(buffer,"******");
	n=write(newsockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");

	//read condition ok or not ok

	bzero(buffer,255);
	n=read(newsockfd,buffer,255); //read ok for network
	if(n<0)
		error("Error on reading");
	printf("%s\n",buffer);

	while(strncmp(buffer,"OK",2)!=0)
	{
		//write the response to change the value
		bzero(buffer,255);
		scanf("%s",buffer);
		n=write(newsockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");
		if(atoi(buffer)==0)
		{
			//registry asked to enter the nnet
			bzero(buffer,255);
			n=read(newsockfd,buffer,255); 
			if(n<0)
				error("Error on reading");
			printf("%s",buffer);

			//entering the nnet
			bzero(buffer,255);
			scanf("%s",buffer);
			n=write(newsockfd,buffer,strlen(buffer));
			if(n<0)
				error("Error on Writing");

		}

		//read ok for network
		bzero(buffer,255);
		n=read(newsockfd,buffer,255); 
		if(n<0)
			error("Error on reading");
		printf("%s\n",buffer);

	}

	bzero(buffer,255);
	strcpy(buffer,"******");
	n=write(newsockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");

	//read condition ok or not ok
	bzero(buffer,255);
	n=read(newsockfd,buffer,255); //read ok for storage
	if(n<0)
	error("Error on reading");
	printf("%s\n",buffer);

	while(strncmp(buffer,"OK",2)!=0)
	{
		//write the response to change the value
		bzero(buffer,255);
		scanf("%s",buffer);
		n=write(newsockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");
		if(atoi(buffer)==0)
		{
			//registry asked to enter the nstrg
			bzero(buffer,255);
			n=read(newsockfd,buffer,255); 
			if(n<0)
				error("Error on reading");
			printf("%s",buffer);

			//entering the nstrg
			bzero(buffer,255);
			scanf("%s",buffer);
			n=write(newsockfd,buffer,strlen(buffer));
			if(n<0)
				error("Error on Writing");

		}

		//read ok for strg
		bzero(buffer,255);
		n=read(newsockfd,buffer,255); 
		if(n<0)
			error("Error on reading");
		printf("%s\n",buffer);

	}

	bzero(buffer,255);
	strcpy(buffer,"******");
	n=write(newsockfd,buffer,strlen(buffer));
	if(n<0)
		error("Error on Writing");

	bzero(buffer,255);
	n=read(newsockfd,buffer,255); //read valid from registry
	if(n<0)
		error("Error on reading");

	if(strncmp(buffer,"valid",5)==0)
	{
		bzero(buffer,255);
		strcpy(buffer,"******");
		n=write(newsockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");

		bzero(buffer,255);
		n=read(newsockfd,buffer,255); //read title skr
		if(n<0)
			error("Error on reading");
		printf("%s",buffer);

		bzero(buffer,255);
		strcpy(buffer,"******");
		n=write(newsockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");


		bzero(buffer,255);
		n=read(newsockfd,buffer,255); //read  skr value
		if(n<0)
			error("Error on reading");
		skr=atoi(buffer);
		printf("%s\n",buffer);

		bzero(buffer,255);
		strcpy(buffer,"******");
		n=write(newsockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");


		bzero(buffer,255);
		n=read(newsockfd,buffer,255); //read title cbname
		if(n<0)
			error("Error on reading");
		printf("%s",buffer);
		sql_conn();
		grab_basevalues();
		//rsa_encryption();

		bzero(buffer,255);
		strcpy(buffer,"******");
		n=write(newsockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");

		bzero(buffer,255);

		//printf("Dec: %s",msn);
		bzero(msn,20);
		n=read(newsockfd,buffer,255); //read cbname value
		strncpy(msn,do_decrypt(buffer,"encreg/cloudname.txt"),sizeof(msn));
		if(n<0)
			error("Error on reading");
		printf("%s\n",msn);

		bzero(buffer,255);
		strcpy(buffer,"******");
		n=write(newsockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");


		bzero(buffer,255);
		n=read(newsockfd,buffer,255); //read title pbkey cloud
		if(n<0)
			error("Error on reading");
		printf("%s",buffer);

		bzero(buffer,255);
		strcpy(buffer,"******");
		n=write(newsockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");

		bzero(msn,20);
		n=read(newsockfd,buffer,255); //read key value
		strncpy(msn,do_decrypt(buffer,"encreg/ckey.txt"),sizeof(msn));
		if(n<0)
			error("Error on reading");
		printf("%s\n",msn);


		bzero(buffer,255);
		strcpy(buffer,"******");
		n=write(newsockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");


		bzero(buffer,255);
		n=read(newsockfd,buffer,255); //read free cpu title
		if(n<0)
			error("Error on reading");
		printf("%s",buffer);

		bzero(buffer,255);
		strcpy(buffer,"******");
		n=write(newsockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");


		bzero(msn,20);
		n=read(newsockfd,buffer,255); //read cpu value
		strncpy(msn,do_decrypt(buffer,"encreg/reqcpu.txt"),sizeof(msn));
		if(n<0)
			error("Error on reading");
		printf("%s\n",msn);

		bzero(buffer,255);
		strcpy(buffer,"******");
		n=write(newsockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");

		bzero(buffer,255);
		n=read(newsockfd,buffer,255); //read free mem title
		if(n<0)
			error("Error on reading");
		printf("%s",buffer);

		bzero(buffer,255);
		strcpy(buffer,"******");
		n=write(newsockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");


		bzero(msn,20);
		n=read(newsockfd,buffer,255); //read mem value
		strncpy(msn,do_decrypt(buffer,"encreg/reqmem.txt"),sizeof(msn));
		if(n<0)
			error("Error on reading");
		printf("%s\n",msn);



		bzero(buffer,255);
		strcpy(buffer,"******");
		n=write(newsockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");


		bzero(buffer,255);
		n=read(newsockfd,buffer,255); //read free net title
		if(n<0)
			error("Error on reading");
		printf("%s",buffer);


		bzero(buffer,255);
		strcpy(buffer,"******");
		n=write(newsockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");

		bzero(msn,20);
		n=read(newsockfd,buffer,255); //read net value
		strncpy(msn,do_decrypt(buffer,"encreg/reqnet.txt"),sizeof(msn));
		if(n<0)
			error("Error on reading");
		printf("%s\n",msn);

		bzero(buffer,255);
		strcpy(buffer,"******");
		n=write(newsockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");


		bzero(buffer,255);
		n=read(newsockfd,buffer,255); //read free strg title
		if(n<0)
			error("Error on reading");
		printf("%s",buffer);

		bzero(buffer,255);
		strcpy(buffer,"******");
		n=write(newsockfd,buffer,strlen(buffer));
		if(n<0)
			error("Error on Writing");


		bzero(msn,20);
		n=read(newsockfd,buffer,255); //read strg value
		strncpy(msn,do_decrypt(buffer,"encreg/reqstrg.txt"),sizeof(msn));
		if(n<0)
			error("Error on reading");
		printf("%s\n",msn);



	}
	close(newsockfd);
	close(sockfd);

}

void printRandoms(int lower, int upper,int count) 
{ 
	int i;
	for (i = 0; i < count; i++) 
	{ 
		num[i]= (rand()%(upper-lower+1))+lower;
	} 
} 

char* do_encrypt(char *msg,char *nm)
{

	x=rx;
	flag = prime(x);
	if(flag == 0)
	{
		printf("\nINVALID INPUT\n");
		exit(0);
	}
	y=ry;
	flag = prime(y);
	if(flag == 0 || x == y)
	{
		printf("\nINVALID INPUT\n");
		exit(0);
	}
	n = x * y;
	t = (x-1) * (y-1);
	encryption_key();
	strcpy(enm,encrypt(msg,nm));
	return(enm);
}
char* do_decrypt(char *msg,char *nm)
{
	x=rx;
	flag = prime(x);
	if(flag == 0)
	{
		printf("\nINVALID INPUT\n");
		exit(0);
	}
	y=ry;
	flag = prime(y);
	if(flag == 0 || x == y)
	{
		printf("\nINVALID INPUT\n");
		exit(0);
	}
	n = x * y;
	t = (x-1) * (y-1);
	encryption_key();
	strcpy(msn,decrypt(enm,nm));
	return(msn);
}
int prime(long int pr)
{
	int i;
	j = sqrt(pr);
	for(i = 2; i <= j; i++)
	{
		if(pr % i == 0)
		return 0;
	}
	return 1;
}

//function to generate encryption key
void encryption_key()
{
	int k;
	k = 0;
	for(i = 2; i < t; i++)
	{
		if(t % i == 0)
			continue;
		flag = prime(i);
		if(flag == 1 && i != x && i != y)
		{
			e[k] = i;
			flag = cd(e[k]);
			if(flag > 0)
			{
				d[k] = flag;
				k++;
			}
			if(k == 99)
				break;
		}
	}
}
long int cd(long int a)
{
	long int k = 1;
	while(1)
	{
		k = k + t;
		if(k % a == 0)
			return(k / a);
	}
}


char* encrypt(char *msg,char *nm)
{

	for(i = 0; msg[i] != '\0'; i++)
	m[i] = msg[i];
	long int pt, ct, key = pkcb, k, len;
	i = 0;

	len = strlen(msg);
	FILE *fptr;

	fptr=fopen(nm,"w");
	// if(fptr!=NULL)
	// {
	// 	printf("File created successfully");
	// }
	// else{
	// 	printf("Failed t0 create");
	// }


	while(i != len)
	{
		pt = m[i];
		pt = pt - 96;
		k = 1;
		for(j = 0; j < key; j++)
		{
			k = k * pt;
			k = (int)k % (int)n;
		}
		temp[i] = k;
		fprintf(fptr, "%ld\n", k);
		//printf("%ld",temp[i]);
		ct = k + 96;
		en[i] = ct;
		i++;
	}
	en[i] = -1;
	for(i = 0; en[i] != -1; i++)
		enm[i]=en[i];
	enm[i]='\0';
	fclose(fptr);
	return(enm);
}

//function to decrypt the message
char* decrypt(char *enm,char *nm)
{

	long int pt, ct, key = skr, k,numb;
	int len;
	i=0;
	FILE *fptr;
	len=strlen(enm);
	fptr=fopen(nm,"r");
	// if(fptr!=NULL)
	// {
	// 	printf("File created successfully");
	// }
	// else{
	// 	printf("Failed t0 create");
	// }

	while(fscanf(fptr,"%ld",&numb)!= -1)
	{
		temp[i]=numb;
		ct = temp[i];
		k = 1;
		for(j = 0; j < key; j++)
		{
			k = k * ct;
			k = k % n;
		}
		pt = k + 96;
		m[i] = pt;
		i++;
	}
	m[i] = -1;
	for(i = 0; m[i] != -1; i++)
		msn[i]=m[i];
	fclose(fptr);
	return(msn);
}

void sql_conn()
{
	conn = mysql_init(NULL);
	/* Connect to database */
	if (!mysql_real_connect(conn, server, user, password,database, 0, NULL, 0)) {
		fprintf(stderr, "%s\n", mysql_error(conn));
	exit(1);
}

}

void grab_basevalues()
{

	char q[500];
	sprintf(q,"select regx,regy from regvalidsign where skr=%ld",skr);
	if (mysql_query(conn,q)) 
	{
		fprintf(stderr, "%s\n", mysql_error(conn));
	exit(1);  
	}

	result = mysql_use_result(conn);

	while ((row = mysql_fetch_row(result)) != NULL)
	{
		rx=atoi(row[0]);
		ry=atoi(row[1]);
	}

	/* close connection */
	mysql_free_result(result);
	mysql_close(conn);
}

void cloud_advertisement()
{

	//strcpy(Server_name,"ServerSA");
	int sockfd,portno,n;
	struct sockaddr_in serv_addr;
	struct hostent *server;
	char buffer[256];
	char hostname[150];

	// printf("Enter the hostname: ");
	// scanf("%s",hostname);
	strcpy(hostname,"localhost");
	printf("Enter the port number: ");
	scanf("%d",&portno);

	sockfd=socket(AF_INET,SOCK_STREAM,0);
	if(sockfd<0)
	{
		error("Error Opening Socket");
	}

	server=gethostbyname(hostname);
	if(server==NULL)
	{
		fprintf(stderr,"Error no such host\n");
		exit(0);	
	}
	bzero((char*)&serv_addr,sizeof(serv_addr));
	serv_addr.sin_family=AF_INET;
	bcopy((char*)server->h_addr,(char*)&serv_addr.sin_addr.s_addr,server->h_length);
	serv_addr.sin_port=htons(portno);
	if(connect(sockfd,(struct sockaddr*)&serv_addr,sizeof(serv_addr))<0)
		error("Connection Failed");

	bzero(buffer,255);
	n=read(sockfd,buffer,255);
	if(n<0)
		error("Error on reading");
	printf("Connected cloud Name : %s\n",buffer);

	n=write(sockfd,Server_Name,strlen(Server_Name));
	if(n<0)
		error("Error on Writing");
	bzero(buffer,256);

	n=read(sockfd,buffer,255);

	if(n<0)
		error("Error on reading");
	printf("\n\n****************************************\n\n");
	printf("%s\n",buffer);
	printf("\n\n****************************************\n\n");

	close(sockfd);


}

int main(int argc,char *argv[])
{
	int choice;

	printf("\nServerSA's process\n\n");

	do 
	{

		printf("1. View Advertisement..\n");
		printf("2. Check valid resources (from Registry)\n");
		printf("3. To connect Cloud\n");
		printf("4. Exit");
		printf("\nPick from choices 1, 2,3, or 4, depending on migration request and response..\n");

		scanf("%d",&choice);

		switch (choice)
		{
			case 1:
				cloud_advertisement();
			    break;

			case 2:
			    registry_connect();
			    break;

			case 3:
			    connect_cloud();
			    break;

			default:
			    printf("Bye...\n");
			    break;
		}
	} while (choice > 0 && choice < 4);


	return(0);

}
